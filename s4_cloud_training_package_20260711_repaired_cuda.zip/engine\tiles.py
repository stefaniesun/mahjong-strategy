from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Suit(str, Enum):
    WAN = "W"
    TIAO = "T"
    BING = "B"


SUITS: tuple[Suit, ...] = (Suit.WAN, Suit.TIAO, Suit.BING)


@dataclass(frozen=True, order=True)
class Tile:
    suit: Suit
    rank: int

    def __post_init__(self) -> None:
        if not isinstance(self.suit, Suit):
            object.__setattr__(self, "suit", Suit(self.suit))
        if self.rank < 1 or self.rank > 9:
            raise ValueError("tile rank must be in 1..9")

    @property
    def index(self) -> int:
        return SUITS.index(self.suit) * 9 + self.rank - 1

    @classmethod
    def from_index(cls, index: int) -> "Tile":
        if index < 0 or index >= 27:
            raise ValueError("tile index must be in 0..26")
        return cls(SUITS[index // 9], index % 9 + 1)


def parse_tile(text: str) -> Tile:
    if len(text) != 2:
        raise ValueError(f"invalid tile text: {text!r}")
    rank_text, suit_text = text[0], text[1]
    if not rank_text.isdigit():
        raise ValueError(f"invalid tile rank: {text!r}")
    try:
        suit = Suit(suit_text)
    except ValueError as exc:
        raise ValueError(f"invalid tile suit: {text!r}") from exc
    return Tile(suit, int(rank_text))


def tile_to_str(tile: Tile) -> str:
    return f"{tile.rank}{tile.suit.value}"


def full_wall() -> list[Tile]:
    return [Tile(suit, rank) for suit in SUITS for rank in range(1, 10) for _ in range(4)]
